import React, { useRef, useEffect, useState, useImperativeHandle } from 'react';
import { InteractionMode, GameStatus, Worker, WallSegment, Enemy, Arrow, Particle, Tree } from '../types';
import { CONSTANTS } from '../constants';
import { audioService } from '../services/audioService';

interface GameCanvasProps {
  status: GameStatus;
  interactionMode: InteractionMode;
  onGameOver: () => void;
  onWin: (timeMs: number, timeStr: string) => void;
  onWorkerSelect: (id: number | null) => void;
  controlRef: React.MutableRefObject<{ startGame: () => void; resetGame: () => void } | null>;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  status,
  interactionMode,
  onGameOver,
  onWin,
  onWorkerSelect,
  controlRef
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);

  // Mutable Game State (Refs for performance/loop access)
  const gameStateRef = useRef<{
    workers: Worker[];
    walls: WallSegment[];
    enemies: Enemy[];
    arrows: Arrow[];
    particles: Particle[];
    trees: Tree[];
    temple: { x: number; y: number; radius: number };
    wallRadius: number;
    gameTime: number;
    lastSpawnTime: number;
    currentSpawnRate: number;
    selectedWorkerId: number | null;
  }>({
    workers: [],
    walls: [],
    enemies: [],
    arrows: [],
    particles: [],
    trees: [],
    temple: { x: 0, y: 0, radius: 45 },
    wallRadius: 100,
    gameTime: 0,
    lastSpawnTime: 0,
    currentSpawnRate: CONSTANTS.BASE_SPAWN_RATE_MS,
    selectedWorkerId: null,
  });

  // Helper to emit time to UI
  const emitTime = () => {
    const totalSec = Math.floor(gameStateRef.current.gameTime / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    const str = `${m < 10 ? '0' + m : m}:${s < 10 ? '0' + s : s}`;
    const timerEl = document.getElementById('game-timer-display');
    if (timerEl) timerEl.innerText = str;
    return str;
  };

  // --- Initialization ---
  const initGame = () => {
    const state = gameStateRef.current;
    state.gameTime = 0;
    state.lastSpawnTime = 0;
    state.currentSpawnRate = CONSTANTS.BASE_SPAWN_RATE_MS;
    state.selectedWorkerId = null;
    state.enemies = [];
    state.arrows = [];
    state.particles = [];

    // Setup Walls
    state.walls = [];
    for (let i = 0; i < CONSTANTS.TOTAL_WALLS; i++) {
      state.walls.push({
        id: i,
        angle: (Math.PI * 2 / CONSTANTS.TOTAL_WALLS) * i,
        state: 'EMPTY',
        progress: 0
      });
    }

    // Setup Workers
    state.workers = [];
    for (let i = 0; i < 3; i++) {
      state.workers.push({
        id: i,
        x: state.temple.x + (Math.random() * 40 - 20),
        y: state.temple.y + (Math.random() * 40 - 20),
        state: 'IDLE',
        targetId: null,
        timer: 0,
        anim: Math.random()
      });
    }
  };

  const resizeGame = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const safeBottom = 120;
    const usableHeight = canvas.height - CONSTANTS.SAFE_TOP_OFFSET - safeBottom;

    const state = gameStateRef.current;
    state.temple.x = canvas.width / 2;
    state.temple.y = CONSTANTS.SAFE_TOP_OFFSET + (usableHeight / 2);
    state.wallRadius = Math.min(canvas.width, usableHeight) * CONSTANTS.WALL_RADIUS_RATIO;

    // Generate trees
    state.trees = [];
    for (let i = 0; i < CONSTANTS.NUM_TREES; i++) {
      const angle = Math.random() * Math.PI * 2;
      const minDist = state.wallRadius + 70;
      const maxDist = Math.max(canvas.width, canvas.height);
      const dist = minDist + Math.random() * (maxDist - minDist);
      state.trees.push({
        x: state.temple.x + Math.cos(angle) * dist,
        y: state.temple.y + Math.sin(angle) * dist,
        size: 30 + Math.random() * 20
      });
    }
  };

  // --- Helpers ---
  const getDist = (x1: number, y1: number, x2: number, y2: number) => Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);

  const moveTo = (obj: { x: number; y: number }, tx: number, ty: number, spd: number) => {
    const d = getDist(obj.x, obj.y, tx, ty);
    if (d > 1) {
      obj.x += ((tx - obj.x) / d) * spd;
      obj.y += ((ty - obj.y) / d) * spd;
    }
    return d;
  };

  const createParticles = (x: number, y: number, color: string) => {
    const state = gameStateRef.current;
    for (let i = 0; i < 8; i++) {
      state.particles.push({
        id: Math.random(),
        x, y,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 0.5) * 5,
        life: 400,
        color
      });
    }
  };

  // --- Main Update Loop ---
  const update = (dt: number) => {
    const state = gameStateRef.current;
    state.gameTime += dt;
    emitTime();

    // Spawning Enemies
    if (state.gameTime > CONSTANTS.SPAWN_DELAY_MS) {
      if (state.gameTime - state.lastSpawnTime > state.currentSpawnRate) {
        const posAngle = Math.random() * Math.PI * 2;
        const dist = Math.max(canvasRef.current!.width, canvasRef.current!.height) / 2 + 50;
        state.enemies.push({
          id: Date.now() + Math.random(),
          posAngle: posAngle,
          x: state.temple.x + Math.cos(posAngle) * dist,
          y: state.temple.y + Math.sin(posAngle) * dist,
          dir: Math.random() > 0.5 ? 1 : -1,
          state: 'CHARGING'
        });
        state.lastSpawnTime = state.gameTime;
        if (state.currentSpawnRate > 1000) state.currentSpawnRate -= 20;
      }
    }

    // Workers Logic
    state.workers.forEach(w => {
      w.anim += dt * 0.005;

      if (w.state === 'MOVE_BUILD') {
        const targetWall = state.walls.find(wl => wl.id === w.targetId);
        if (targetWall) {
            // Need current target position
            const tx = state.temple.x + Math.cos(targetWall.angle) * state.wallRadius;
            const ty = state.temple.y + Math.sin(targetWall.angle) * state.wallRadius;
            
            const d = moveTo(w, tx, ty, CONSTANTS.WORKER_SPEED * dt);
            if (d < 5) {
                w.state = 'BUILDING';
                w.timer = 0;
                audioService.playSfx('hammer');
            }
        } else {
            // Wall gone?
            w.state = 'IDLE';
        }
      } else if (w.state === 'BUILDING') {
        const targetWall = state.walls.find(wl => wl.id === w.targetId);
        if (!targetWall) {
            w.state = 'IDLE';
            return;
        }
        w.timer += dt;
        targetWall.progress = w.timer / CONSTANTS.BUILD_TIME_MS;
        if (w.timer >= CONSTANTS.BUILD_TIME_MS) {
            targetWall.state = 'BUILT';
            w.state = 'RETURN';
            
            // Check Win
            if (state.walls.every(s => s.state === 'BUILT')) {
                onWin(state.gameTime, emitTime());
                audioService.playSfx('win');
            }
        }
        if (w.timer % 600 < dt) audioService.playSfx('hammer');

      } else if (w.state === 'RETURN') {
          const d = moveTo(w, state.temple.x, state.temple.y, CONSTANTS.WORKER_SPEED * dt);
          if (d < 30) w.state = 'IDLE';
      }
    });

    // Enemies Logic
    for (let i = state.enemies.length - 1; i >= 0; i--) {
      const e = state.enemies[i];
      const dx = state.temple.x - e.x;
      const dy = state.temple.y - e.y;
      const distCenter = Math.sqrt(dx * dx + dy * dy);
      
      e.posAngle = Math.atan2(e.y - state.temple.y, e.x - state.temple.x);
      if (e.posAngle < 0) e.posAngle += Math.PI * 2;

      const currentSpeed = CONSTANTS.ENEMY_SPEED * dt;
      const collisionDist = state.wallRadius + 25;

      let blocked = false;
      if (distCenter < collisionDist && distCenter > state.wallRadius - 10) {
          const segmentArc = (Math.PI * 2) / CONSTANTS.TOTAL_WALLS;
          const segIndex = Math.round(e.posAngle / segmentArc) % CONSTANTS.TOTAL_WALLS;
          const targetSegment = state.walls[segIndex];
          if (targetSegment && targetSegment.state === 'BUILT') blocked = true;
      }

      if (blocked) {
          e.posAngle += (currentSpeed * 0.015) * e.dir;
          e.x = state.temple.x + Math.cos(e.posAngle) * collisionDist;
          e.y = state.temple.y + Math.sin(e.posAngle) * collisionDist;
      } else {
          e.x += Math.cos(Math.atan2(dy, dx)) * currentSpeed;
          e.y += Math.sin(Math.atan2(dy, dx)) * currentSpeed;
      }

      if (distCenter < state.temple.radius) {
          audioService.playSfx('lose');
          onGameOver();
      }
    }

    // Arrows Logic
    for (let i = state.arrows.length - 1; i >= 0; i--) {
        const a = state.arrows[i];
        a.x += Math.cos(a.angle) * CONSTANTS.ARROW_SPEED * dt;
        a.y += Math.sin(a.angle) * CONSTANTS.ARROW_SPEED * dt;
        
        let hit = false;
        for (let j = state.enemies.length - 1; j >= 0; j--) {
            const e = state.enemies[j];
            if (getDist(a.x, a.y, e.x, e.y) < 35) {
                createParticles(e.x, e.y, CONSTANTS.COLORS.PARTICLE_BLOOD);
                state.enemies.splice(j, 1);
                state.arrows.splice(i, 1);
                audioService.playSfx('hit');
                hit = true;
                break;
            }
        }
        
        if (!hit && (a.x < -50 || a.x > canvasRef.current!.width + 50 || a.y < -50 || a.y > canvasRef.current!.height + 50)) {
            state.arrows.splice(i, 1);
        }
    }

    // Particles Logic
    for (let i = state.particles.length - 1; i >= 0; i--) {
        const p = state.particles[i];
        p.life -= dt;
        p.x += p.vx;
        p.y += p.vy;
        if (p.life <= 0) state.particles.splice(i, 1);
    }
  };

  // --- Rendering ---
  const draw = () => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx || !canvasRef.current) return;
    const state = gameStateRef.current;
    const width = canvasRef.current.width;
    const height = canvasRef.current.height;

    // Clear
    ctx.fillStyle = CONSTANTS.COLORS.BG;
    ctx.fillRect(0, 0, width, height);

    // Temple Ground Gradient
    const g = ctx.createRadialGradient(state.temple.x, state.temple.y, 40, state.temple.x, state.temple.y, state.wallRadius + 40);
    g.addColorStop(0, '#e6b885');
    g.addColorStop(1, 'rgba(125, 174, 95, 0.1)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(state.temple.x, state.temple.y, state.wallRadius + 40, 0, Math.PI * 2);
    ctx.fill();

    // Trees
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    state.trees.forEach(t => {
        ctx.font = `${Math.floor(t.size)}px Arial`;
        ctx.fillText('🌳', t.x, t.y);
    });

    // Temple Icon
    ctx.save();
    ctx.translate(state.temple.x, state.temple.y);
    ctx.font = '80px serif';
    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.beginPath();
    ctx.ellipse(0, 30, 50, 15, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillText('🏛️', 0, 0);
    ctx.restore();

    // Walls
    state.walls.forEach(s => {
        const wx = state.temple.x + Math.cos(s.angle) * state.wallRadius;
        const wy = state.temple.y + Math.sin(s.angle) * state.wallRadius;

        ctx.save();
        ctx.translate(wx, wy);
        ctx.rotate(s.angle + Math.PI / 2);

        const blockWidth = 40;
        const blockHeight = 15;

        if (s.state === 'BUILT') {
            ctx.fillStyle = CONSTANTS.COLORS.WALL_BUILT;
            ctx.fillRect(-blockWidth / 2, -blockHeight / 2, blockWidth, blockHeight);
            ctx.strokeStyle = CONSTANTS.COLORS.WALL_OUTLINE;
            ctx.lineWidth = 3;
            ctx.strokeRect(-blockWidth / 2, -blockHeight / 2, blockWidth, blockHeight);
            ctx.beginPath(); ctx.moveTo(0, -blockHeight/2); ctx.lineTo(0, blockHeight/2); ctx.stroke();
        } else if (s.state === 'BUILDING' || s.progress > 0) {
            ctx.strokeStyle = CONSTANTS.COLORS.WALL_BUILDING;
            ctx.lineWidth = 3;
            ctx.strokeRect(-blockWidth / 2, -blockHeight / 2, blockWidth, blockHeight);
            ctx.fillStyle = 'rgba(211, 84, 0, 0.6)';
            ctx.fillRect(-blockWidth / 2, blockHeight / 2 - (blockHeight * s.progress), blockWidth, blockHeight * s.progress);
        } else {
            ctx.strokeStyle = CONSTANTS.COLORS.WALL_RESERVED;
            ctx.setLineDash([6, 6]);
            ctx.lineWidth = 2;
            ctx.strokeRect(-blockWidth / 2, -blockHeight / 2, blockWidth, blockHeight);
        }
        ctx.restore();
    });

    // Workers
    state.workers.forEach(w => {
        ctx.save();
        ctx.translate(w.x, w.y);
        // Selection highlight
        if (w.id === state.selectedWorkerId) {
            ctx.beginPath();
            ctx.arc(0, 0, 25, 0, Math.PI * 2);
            ctx.strokeStyle = '#f1c40f';
            ctx.lineWidth = 3;
            ctx.stroke();
        }
        ctx.translate(0, Math.sin(w.anim * 8) * 3);
        // Shadow
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.ellipse(0, 15, 12, 6, 0, 0, Math.PI * 2);
        ctx.fill();
        // Emoji
        ctx.font = '35px Arial';
        ctx.fillText('👷', 0, 0);
        ctx.restore();
    });

    // Enemies
    state.enemies.forEach(e => {
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.rotate(Math.sin(state.gameTime * 0.03) * 0.2);
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.ellipse(0, 15, 15, 8, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = '35px Arial';
        ctx.strokeStyle = 'white'; ctx.lineWidth = 2;
        ctx.strokeText('😡', 0, 0);
        ctx.fillStyle = 'red';
        ctx.fillText('😡', 0, 0);
        ctx.restore();
    });

    // Arrows
    ctx.strokeStyle = '#8e44ad';
    ctx.lineWidth = 3;
    state.arrows.forEach(a => {
        ctx.save();
        ctx.translate(a.x, a.y);
        ctx.rotate(a.angle);
        ctx.beginPath();
        ctx.moveTo(-8, 0);
        ctx.lineTo(8, 0);
        ctx.stroke();
        ctx.restore();
    });

    // Particles
    state.particles.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / 400;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
    });
  };

  const gameLoop = (time: number) => {
    const dt = time - lastTimeRef.current;
    lastTimeRef.current = time;
    const delta = Math.min(dt, 60); // Cap delta

    if (status === 'PLAYING') {
      update(delta);
    }
    
    draw();
    requestRef.current = requestAnimationFrame(gameLoop);
  };

  // --- Interactions ---
  const handlePointerDown = (e: React.PointerEvent) => {
    if (status !== 'PLAYING') return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const state = gameStateRef.current;

    // Check Worker Click
    let clickedId: number | null = null;
    for (const w of state.workers) {
        if (getDist(x, y, w.x, w.y) < 45) {
            clickedId = w.id;
            break;
        }
    }

    if (clickedId !== null) {
        const w = state.workers.find(w => w.id === clickedId);
        if (w && w.state !== 'BUILDING') {
            state.selectedWorkerId = clickedId;
            onWorkerSelect(clickedId);
            audioService.playSfx('select');
            return;
        }
    }

    // Handle Action if Worker Selected
    if (state.selectedWorkerId !== null) {
        const w = state.workers.find(w => w.id === state.selectedWorkerId);
        if (!w) return;

        if (interactionMode === 'BUILD') {
            // Find closest empty wall
            let bestDist = 75;
            let bestSeg: WallSegment | null = null;
            
            for (const s of state.walls) {
                if (s.state === 'EMPTY') {
                    const wx = state.temple.x + Math.cos(s.angle) * state.wallRadius;
                    const wy = state.temple.y + Math.sin(s.angle) * state.wallRadius;
                    const d = getDist(x, y, wx, wy);
                    if (d < bestDist) {
                        bestDist = d;
                        bestSeg = s;
                    }
                }
            }

            if (bestSeg) {
                // Clear old target reservation if switching
                if (w.state === 'MOVE_BUILD' && w.targetId !== null && w.targetId !== bestSeg.id) {
                     const oldT = state.walls.find(wl => wl.id === w.targetId);
                     if (oldT && oldT.state === 'RESERVED') oldT.state = 'EMPTY';
                }

                w.state = 'MOVE_BUILD';
                w.targetId = bestSeg.id;
                bestSeg.state = 'RESERVED';
                state.selectedWorkerId = null;
                onWorkerSelect(null);
                audioService.playSfx('select');
            }
        } else if (interactionMode === 'ATTACK') {
            let bestDist = 65;
            let bestEnemy: Enemy | null = null;
            
            for (const en of state.enemies) {
                const d = getDist(x, y, en.x, en.y);
                if (d < bestDist) {
                    bestDist = d;
                    bestEnemy = en;
                }
            }

            if (bestEnemy) {
                // If attacking, drop building task
                if (w.state === 'MOVE_BUILD' && w.targetId !== null) {
                     const oldT = state.walls.find(wl => wl.id === w.targetId);
                     if (oldT && oldT.state === 'RESERVED') oldT.state = 'EMPTY';
                     w.targetId = null;
                }

                const ang = Math.atan2(bestEnemy.y - w.y, bestEnemy.x - w.x);
                state.arrows.push({ id: Math.random(), x: w.x, y: w.y, angle: ang });
                audioService.playSfx('arrow');
                state.selectedWorkerId = null;
                onWorkerSelect(null);
            }
        }
    }
  };

  // --- Lifecycle ---

  useImperativeHandle(controlRef, () => ({
      startGame: () => {
          initGame();
          audioService.startMusic(true);
      },
      resetGame: () => {
          audioService.startMusic(false);
          // Reset handled by initGame on next start
      }
  }));

  useEffect(() => {
    resizeGame();
    window.addEventListener('resize', resizeGame);
    requestRef.current = requestAnimationFrame(gameLoop);
    
    return () => {
        window.removeEventListener('resize', resizeGame);
        cancelAnimationFrame(requestRef.current);
        audioService.startMusic(false);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]); // Re-bind when status changes to ensure update loop catches it, though ref based logic handles most

  return (
    <canvas
        ref={canvasRef}
        className="block w-full h-full"
        onPointerDown={handlePointerDown}
    />
  );
};