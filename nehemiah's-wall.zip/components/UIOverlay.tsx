import React, { useEffect, useState } from 'react';
import { GameStatus, InteractionMode, LeaderboardEntry } from '../types';
import { leaderboardService } from '../services/leaderboardService';
import { Hammer, Swords, Clock, Trophy } from 'lucide-react';

interface UIOverlayProps {
  status: GameStatus;
  playerName: string;
  finalTime: string;
  interactionMode: InteractionMode;
  activeWorkerId: number | null;
  onAdvance: () => void;
  onStartGame: (name: string) => void;
  onReset: () => void;
  setInteractionMode: (m: InteractionMode) => void;
}

export const UIOverlay: React.FC<UIOverlayProps> = ({
  status,
  finalTime,
  interactionMode,
  activeWorkerId,
  onAdvance,
  onStartGame,
  onReset,
  setInteractionMode
}) => {
  const [inputName, setInputName] = useState('');
  const [scores, setScores] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    if (status === 'NAME_INPUT' || status === 'WON') {
      const unsubscribe = leaderboardService.subscribe((newScores) => {
        setScores(newScores);
      });
      return () => unsubscribe();
    }
  }, [status]);

  // --- Screens ---

  if (status === 'INSTRUCTIONS') {
    return (
      <div className="absolute inset-0 bg-[rgba(14,20,25,0.96)] z-20 flex flex-col items-center justify-center p-6 text-center overflow-y-auto">
        <h1 className="font-cinzel text-[#f1c40f] text-3xl md:text-4xl mb-4 drop-shadow-lg">Defend Jerusalem</h1>
        <div className="text-[#bdc3c7] text-base md:text-lg max-w-lg space-y-3 mb-8 text-left mx-auto">
          <p>1. <span className="text-white font-bold">Protect the Temple</span> (🏛️) in the center.</p>
          <p>2. Select a Worker (👷), then click <span className="inline-block align-bottom"><Hammer size={18}/></span> to <span className="text-white font-bold">build walls</span>.</p>
          <p>3. Select a Worker (👷), then click <span className="inline-block align-bottom"><Swords size={18}/></span> to <span className="text-white font-bold">attack enemies</span>.</p>
          <p>4. Don't let enemies reach the center!</p>
        </div>
        <button 
          onClick={onAdvance}
          className="bg-[#e67e22] text-white font-cinzel text-xl py-3 px-10 rounded-full shadow-[0_5px_0_#d35400] active:translate-y-1 active:shadow-none transition-all"
        >
          Continue
        </button>
        <div className="mt-8 bg-white/10 p-4 rounded-lg border-l-4 border-[#f1c40f] text-gray-200 italic max-w-xl text-sm">
          "Those who carried materials did their work with one hand and held a weapon in the other."
          <br/>
          <span className="block mt-2 text-xs opacity-80">- Nehemiah 4:17</span>
        </div>
      </div>
    );
  }

  if (status === 'NAME_INPUT') {
    return (
      <div className="absolute inset-0 bg-[rgba(14,20,25,0.96)] z-20 flex flex-col items-center justify-center p-6">
        <h1 className="font-cinzel text-[#f1c40f] text-3xl mb-2">Identity</h1>
        <p className="text-[#bdc3c7] mb-6">Enter your name for the builder's log.</p>
        
        <div className="flex flex-col gap-4 w-full max-w-xs mb-8">
          <input 
            type="text" 
            value={inputName}
            onChange={(e) => setInputName(e.target.value)}
            maxLength={12}
            placeholder="Your Name"
            className="p-3 text-center bg-black/50 border-2 border-[#f1c40f] rounded-lg text-white text-lg outline-none focus:shadow-[0_0_15px_rgba(241,196,15,0.5)]"
          />
          <button 
            onClick={() => inputName.trim() && onStartGame(inputName.trim())}
            className="bg-[#e67e22] text-white font-cinzel text-xl py-3 rounded-full shadow-[0_5px_0_#d35400] active:translate-y-1 active:shadow-none transition-all disabled:opacity-50 disabled:shadow-none disabled:translate-y-1"
            disabled={!inputName.trim()}
          >
            Start Building
          </button>
        </div>

        <div className="w-full max-w-md bg-black/60 rounded-lg border border-gray-600 p-4 max-h-60 overflow-y-auto">
            <h3 className="text-[#f1c40f] font-cinzel text-center border-b border-gray-600 pb-2 mb-2 flex items-center justify-center gap-2">
                <Trophy size={18}/> Global Ranking
            </h3>
            <ul className="space-y-2">
                {scores.length === 0 ? (
                    <li className="text-center text-gray-500 text-sm italic">Connecting to builders log...</li>
                ) : (
                    scores.map((s, i) => (
                        <li key={i} className="flex justify-between text-gray-300 text-sm border-b border-white/10 pb-1">
                            <span>
                                {i === 0 && '🥇 '}
                                {i === 1 && '🥈 '}
                                {i === 2 && '🥉 '}
                                {i > 2 && `${i + 1}. `}
                                {s.name}
                            </span>
                            <span className="font-mono">{s.timeStr}</span>
                        </li>
                    ))
                )}
            </ul>
        </div>
      </div>
    );
  }

  if (status === 'GAMEOVER') {
    return (
      <div className="absolute inset-0 bg-[rgba(14,20,25,0.96)] z-20 flex flex-col items-center justify-center p-6 text-center">
        <h1 className="font-cinzel text-[#e74c3c] text-4xl mb-4 animate-pulse">Breach!</h1>
        <p className="text-[#bdc3c7] mb-8">The enemy has entered the temple. Jerusalem has fallen.</p>
        <button 
          onClick={onReset}
          className="bg-[#e67e22] text-white font-cinzel text-xl py-3 px-12 rounded-full shadow-[0_5px_0_#d35400] active:translate-y-1 active:shadow-none transition-all"
        >
          Try Again
        </button>
      </div>
    );
  }

  if (status === 'WON') {
    return (
      <div className="absolute inset-0 bg-[rgba(14,20,25,0.96)] z-20 flex flex-col items-center justify-center p-6 text-center">
        <h1 className="font-cinzel text-[#2ecc71] text-4xl mb-4">Wall Completed!</h1>
        <p className="text-[#bdc3c7] mb-2">Jerusalem is secure.</p>
        <div className="text-[#f1c40f] text-2xl font-bold font-mono mb-8">Time: {finalTime}</div>
        <button 
          onClick={onReset}
          className="bg-[#e67e22] text-white font-cinzel text-xl py-3 px-12 rounded-full shadow-[0_5px_0_#d35400] active:translate-y-1 active:shadow-none transition-all"
        >
          Leaderboard
        </button>
      </div>
    );
  }

  // --- HUD (Playing) ---

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between z-10">
      {/* Top Timer */}
      <div className="w-full flex justify-center pt-4">
        <div className="flex items-center gap-2 bg-black/50 backdrop-blur-sm text-[#f1c40f] px-4 py-1 rounded-full border border-white/30 font-cinzel text-xl">
            <Clock size={20} />
            <span id="game-timer-display">00:00</span>
        </div>
      </div>

      {/* Message Box */}
      <div className="absolute bottom-32 w-full text-center">
         <div className="text-white text-lg md:text-xl font-bold drop-shadow-md bg-black/30 inline-block px-4 py-1 rounded-lg backdrop-blur-sm">
            {activeWorkerId === null 
                ? "Select a Worker 👷"
                : interactionMode === 'BUILD' 
                    ? "Tap a gap to Build 🔨" 
                    : "Tap an enemy to Attack ⚔️"
            }
         </div>
      </div>

      {/* Bottom Controls */}
      <div className="w-full flex justify-center items-center pb-10 gap-10 pointer-events-auto">
        <button 
            onClick={() => setInteractionMode('BUILD')}
            className={`w-16 h-16 rounded-full border-4 flex items-center justify-center transition-all shadow-lg ${
                interactionMode === 'BUILD' 
                ? 'bg-[#f1c40f] border-white text-[#2c3e50] scale-110 shadow-[0_0_20px_rgba(241,196,15,0.6)]' 
                : 'bg-[#34495e] border-white/80 text-white hover:bg-[#2c3e50]'
            }`}
        >
            <Hammer size={32} />
        </button>

        <button 
            onClick={() => setInteractionMode('ATTACK')}
            className={`w-16 h-16 rounded-full border-4 flex items-center justify-center transition-all shadow-lg ${
                interactionMode === 'ATTACK' 
                ? 'bg-[#f1c40f] border-white text-[#2c3e50] scale-110 shadow-[0_0_20px_rgba(241,196,15,0.6)]' 
                : 'bg-[#34495e] border-white/80 text-white hover:bg-[#2c3e50]'
            }`}
        >
            <Swords size={32} />
        </button>
      </div>
    </div>
  );
};