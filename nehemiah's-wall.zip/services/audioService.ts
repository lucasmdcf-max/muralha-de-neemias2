class AudioService {
    private ctx: AudioContext | null = null;
    private musicTimer: number | null = null;
  
    public async init() {
      if (!this.ctx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          this.ctx = new AudioContextClass();
          // Resume if suspended (browser policy)
          if (this.ctx.state === 'suspended') {
            await this.ctx.resume();
          }
          // Silent buffer to unlock audio on some devices
          const buffer = this.ctx.createBuffer(1, 1, 22050);
          const source = this.ctx.createBufferSource();
          source.buffer = buffer;
          source.connect(this.ctx.destination);
          source.start(0);
        }
      }
    }
  
    private playTone(freq: number, type: OscillatorType, duration: number, vol: number = 0.1) {
      if (!this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        
        gain.gain.setValueAtTime(vol, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);
        
        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {
        console.warn('Audio play error', e);
      }
    }
  
    public playSfx(id: 'select' | 'hammer' | 'arrow' | 'hit' | 'win' | 'lose') {
      if (!this.ctx) return;
  
      switch (id) {
        case 'select':
          this.playTone(800, 'sine', 0.1);
          break;
        case 'hammer':
          this.playTone(150, 'square', 0.08);
          break;
        case 'arrow':
          this.playTone(1200, 'triangle', 0.15);
          break;
        case 'hit':
          this.playTone(100, 'sawtooth', 0.1);
          break;
        case 'win':
          this.playTone(600, 'sine', 0.2, 0.2);
          setTimeout(() => this.playTone(900, 'sine', 0.4, 0.2), 200);
          break;
        case 'lose':
          this.playTone(100, 'sawtooth', 0.5, 0.3);
          break;
      }
    }
  
    public startMusic(isPlaying: boolean) {
      if (this.musicTimer) {
        window.clearInterval(this.musicTimer);
        this.musicTimer = null;
      }
  
      if (isPlaying) {
        let beat = 0;
        this.musicTimer = window.setInterval(() => {
          if (beat % 4 === 0) {
            this.playTone(70, 'square', 0.1, 0.05);
          }
          beat++;
        }, 180);
      }
    }
  }
  
  export const audioService = new AudioService();