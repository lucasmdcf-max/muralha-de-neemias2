import { LeaderboardEntry } from '../types';

declare global {
  interface Window {
    GameServices?: {
      saveScore: (entry: any) => Promise<void>;
      subscribeToLeaderboard: (callback: (scores: any[]) => void) => () => void;
    }
  }
}

export const leaderboardService = {
  subscribe: (callback: (scores: LeaderboardEntry[]) => void): (() => void) => {
    if (typeof window !== 'undefined' && window.GameServices && window.GameServices.subscribeToLeaderboard) {
      return window.GameServices.subscribeToLeaderboard((data) => {
        // Ensure data matches LeaderboardEntry structure
        const validScores = data.map(d => ({
            name: d.name || 'Anonymous',
            timeMs: d.timeMs || 0,
            timeStr: d.timeStr || '00:00',
            timestamp: d.timestamp || Date.now()
        }));
        callback(validScores);
      });
    }
    
    // Fallback for offline or no-firebase context (Load local)
    const stored = localStorage.getItem('nehemiah_wall_leaderboard');
    const localScores = stored ? JSON.parse(stored) : [];
    callback(localScores);
    return () => {};
  },

  addScore: (entry: LeaderboardEntry) => {
    // 1. Save Online
    if (typeof window !== 'undefined' && window.GameServices && window.GameServices.saveScore) {
      window.GameServices.saveScore(entry);
    }
    
    // 2. Also save locally as backup/optimistic update
    try {
        const stored = localStorage.getItem('nehemiah_wall_leaderboard');
        const scores = stored ? JSON.parse(stored) : [];
        scores.push(entry);
        scores.sort((a: any, b: any) => a.timeMs - b.timeMs);
        localStorage.setItem('nehemiah_wall_leaderboard', JSON.stringify(scores.slice(0, 50)));
    } catch(e) {
        console.warn("Local storage failed", e);
    }
  }
};